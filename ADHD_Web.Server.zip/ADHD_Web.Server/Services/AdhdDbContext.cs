using ADHD_Web.Server.Models;
using Microsoft.EntityFrameworkCore;

namespace ADHD_Web.Server.Services;

public class AdhdDbContext(DbContextOptions<AdhdDbContext> options) : DbContext(options)
{
    public required DbSet<Players> Players { get; set; }
    public required DbSet<Levels> Levels { get; set; }
    public required DbSet<PlayerLevel> PlayerLevels { get; set; }

    // protected override void OnModelCreating(ModelBuilder modelBuilder)
    // {
    //     base.OnModelCreating(modelBuilder);
    //     // Player 实体配置
    //     modelBuilder.Entity<Players>(entity =>
    //     {
    //         entity.HasKey(e => e.PlayerId);
    //         entity.Property(e => e.PlayerId).ValueGeneratedOnAdd();
    //         entity.Property(e => e.Name).IsRequired();
    //         entity.Property(e => e.Age).IsRequired();
    //         entity.Property(e => e.Gender).IsRequired();
    //         entity.Property(e => e.CreatedAt).IsRequired();
    //         
    //         // 建立索引
    //         entity.HasIndex(e => e.Name);
    //         entity.HasIndex(e => e.Age);
    //         entity.HasIndex(e => e.Gender);
    //     });
    //
    //     // Level 实体配置
    //     modelBuilder.Entity<Levels>(entity =>
    //     {
    //         entity.HasKey(e => e.LevelId);
    //         entity.Property(e => e.LevelName).IsRequired();
    //         entity.Property(e => e.Difficulty).IsRequired();
    //         entity.Property(e => e.CreatedAt).IsRequired();
    //         
    //         // 建立索引
    //         entity.HasIndex(e => e.LevelName);
    //         entity.HasIndex(e => e.Difficulty);
    //     });
    //
    //     // PlayerLevel 实体配置
    //     modelBuilder.Entity<PlayerLevel>(entity =>
    //     {
    //         entity.HasKey(e => new { e.PlayerId, e.LevelId });
    //         entity.Property(e => e.IsCompleted).IsRequired();
    //         entity.Property(e => e.TimeSpent).IsRequired();
    //         entity.Property(e => e.CreatedAt).IsRequired();
    //         
    //         // 建立索引
    //         entity.HasIndex(e => e.PlayerId);
    //         entity.HasIndex(e => e.LevelId);
    //         entity.HasIndex(e => e.IsCompleted);
    //     });
    // }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Players
        modelBuilder.Entity<Players>(entity =>
        {
            entity.ToTable("Players");
            entity.HasKey(e => e.PlayerId);
            entity.Property(e => e.Name).IsRequired().HasMaxLength(50);
            entity.Property(e => e.Age).IsRequired();
            entity.Property(e => e.Gender).IsRequired().HasMaxLength(10);
            entity.Property(e => e.CreatedAt).IsRequired();
        });

        // Levels
        modelBuilder.Entity<Levels>(entity =>
        {
            entity.ToTable("Levels");
            entity.HasKey(e => e.LevelId);
            entity.Property(e => e.LevelName).IsRequired().HasMaxLength(50);
            entity.Property(e => e.Difficulty).IsRequired().HasMaxLength(10);
            entity.Property(e => e.CreatedAt).IsRequired();
        });

        // PlayerLevels
        modelBuilder.Entity<PlayerLevel>(entity =>
        {
            entity.ToTable("PlayerLevels");
            entity.HasKey(e => new { e.PlayerId, e.LevelId });
            entity.HasOne(pl => pl.Player)
                .WithMany(p => p.PlayerLevels)
                .HasForeignKey(pl => pl.PlayerId);
            entity.HasOne(pl => pl.Level)
                .WithMany(l => l.PlayerLevels)
                .HasForeignKey(pl => pl.LevelId);
            entity.Property(pl => pl.IsCompleted).IsRequired();
            entity.Property(pl => pl.TimeSpent).IsRequired();
            entity.Property(pl => pl.CreatedAt).IsRequired();
        });
    }
}