namespace ADHD_Web.Server.Utils;

public static class StringUtils
{
    
}