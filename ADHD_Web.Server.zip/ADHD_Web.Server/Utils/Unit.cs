namespace ADHD_Web.Server.Utils;

public struct Unit
{
    public static readonly Unit Value = new();
}